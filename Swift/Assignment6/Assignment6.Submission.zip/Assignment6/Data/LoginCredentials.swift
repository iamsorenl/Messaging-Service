import Foundation

struct LoginCredentials: Codable {
    let email: String
    let password: String
}
