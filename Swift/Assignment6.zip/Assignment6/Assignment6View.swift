
import SwiftUI

struct Assignment6View: View {
  var body: some View {
    VStack {
      Spacer()
      Text("CSE118 Assignment 6")
      Image("SlugLogo")
        .resizable()
        .aspectRatio(contentMode: .fill)
        .frame(width: 150, height: 150)
        .clipped()
      Spacer()
      Spacer()
    }
    .padding()
  }
}

#if !TESTING
struct MainView_Previews: PreviewProvider {
  static var previews: some View {
    Assignment6View()
  }
}
#endif
