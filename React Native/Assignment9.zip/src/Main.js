import React from 'react';
import {Text} from 'react-native';

export default Main = () => {
  return (
    <Text>CSE118 Assignment 9</Text>
  );
};

