import React from 'react';
import Main from './src/Main';

export default App = () => {
  return <Main />;
};
