export class LoginResponse {
  constructor(id, name, accessToken) {
    this.id = id;
    this.name = name;
    this.accessToken = accessToken;
  }
}
