export class LoginCredentials {
  constructor(email, password) {
    this.email = email;
    this.password = password;
  }
}
